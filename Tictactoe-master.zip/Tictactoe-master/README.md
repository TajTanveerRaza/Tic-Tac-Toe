## Description
**Tic Tac Toe** game written in C Language
## Technology
#### C Language
## Screen Shots
![Alt text](https://raw.githubusercontent.com/vsncipher/Tictactoe/master/scrshots/scr1.PNG "scr1")


## Contact
#### Developer
* Homepage: [https://vsncipher.github.io/me](https://vsncipher.github.io/me).
* e-mail: vsrinivasanikhil@gmail.com
* Twitter: [@srinivasanikhil](https://twitter.com/srinivasanikhil "twitterhandle on twitter")
